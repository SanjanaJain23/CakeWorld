mainController.service('getAllCakesService', function ($http) {
    
    return {
        getCakesData: function () {
            return $http({
                method: 'GET',
                url: 'http://ec2-52-209-201-89.eu-west-1.compute.amazonaws.com:5000/api/cakes',
                headers: {'Content-Type': 'application/json'}
            }).then(function successCallback(response) {
                return response.data;
            }, function errorCallback(response) { });
        }
    }


});
var app = angular.module('myApp', ['mainController', 'ngRoute', 'ui.bootstrap'])

var mainController = angular.module('mainController', []);

// Opening fancybox
mainController.directive('fancybox', function($compile) {
  return {
    restrict: 'A',
    replace: false,
    link: function($scope, element, attrs) {

      $scope.openAddCakePopup = function() {
        
        var el = angular.element(element.html()),

        compiled = $compile(el);
        
        $.fancybox.open(el);

        compiled($scope);
     
      };
    }
  };
});


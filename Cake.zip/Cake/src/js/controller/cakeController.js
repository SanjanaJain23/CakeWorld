mainController.controller('cakeController',
        ['$scope', '$http', '$route', function ($scope, $http, $route) {

        		// Getting cake id and assigning to cakeId
            	var cakeId = $route.current.params.q;

            	// Assigning scope variables
            	$scope.getAllCakeInnerData = [];
            	$scope.isReadonly = true;

            	// Fetching innerpage cake details with cakeId
                $http({
                    method: 'GET',
                    url: 'http://ec2-52-209-201-89.eu-west-1.compute.amazonaws.com:5000/api/cakes/'+cakeId,
                    headers: {'Content-Type': 'application/json'}
                }).then(function successCallback(response) {
                	$scope.getAllCakeInnerData = response.data;
                	$scope.rating = response.data.yumFactor;
                });

				// Go back to allCakes view on click
                $scope.goBack = function() { 
					window.history.back();
				};
         	}
        ]
);
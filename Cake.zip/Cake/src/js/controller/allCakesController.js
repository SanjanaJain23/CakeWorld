mainController.controller('allCakesController',
        ['$scope', '$http', 'getAllCakesService', '$anchorScroll', '$location', function ($scope, $http, getAllCakesService, $anchorScroll, $location) {

				$scope.rate = 0;
				$scope.cakeName = "";
				$scope.cakeComent = "";
            	$scope.getAllCakesData = [];

            	// Render allCakes view with all cakes
                getAllCakesService.getCakesData().then(function (response) {
                    $scope.getAllCakesData = response;      
               });

                // Function to go to end of page
                $scope.gotoBottom = function() {
			      $location.hash('eop');
			      $anchorScroll();
			    };

                // On add cake submit
                $scope.cakeSubmit = function(){
                	//if form is not valid then return the form.
				     if(!$scope.cakeForm.$valid) {
				       return false;
				     }

	                var formData = {
	                	name: $scope.cakeName,
	                	comment: $scope.cakeComent,
	                	yumFactor: $scope.rate,
	                	imageUrl : "http://www.manna.nf.ca/wp-content/uploads/2016/06/cake.png"
	                }

      	         	$http({
	                    method: 'POST',
	                    url: 'http://ec2-52-209-201-89.eu-west-1.compute.amazonaws.com:5000/api/cakes',
	                    data: formData,
                    	headers: {'Content-Type': 'application/json'}
	                }).then(function successCallback(response) {
	                	// Close fancy box 
	                	$.fancybox.close();

	                	// Render allCakes view with all cakes
	                	getAllCakesService.getCakesData().then(function (response) {
		                    $scope.getAllCakesData = response;      
		               });

	          			// Call gotoBottom function to go end of page;
					     $scope.gotoBottom();

	                	// Reset the form elements
	                	$scope.rate = 0;
						$scope.cakeName = "";
						$scope.cakeComent = "";
	                })
         		}

         	}
        ]
);
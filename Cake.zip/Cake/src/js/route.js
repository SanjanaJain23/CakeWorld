app.config(['$routeProvider', function ($routeProvider) {
        $routeProvider.
                when('/cakes', {
                    templateUrl: '../partials/allCakes.tmpl',
                    controller: 'allCakesController'
                }).
                when('/cake/:q', {
                    templateUrl: '../partials/cake.tmpl',
                    controller: 'cakeController'
                }).
                otherwise({
                    redirectTo: '/cakes',
                    controller: 'allCakesController'
                });
    }]);